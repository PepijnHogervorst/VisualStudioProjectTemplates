﻿using System.Windows;

namespace $safeprojectname$.Converters;

internal class BooleanToFontWeightConverter : BooleanConverter<FontWeight>
{
    public BooleanToFontWeightConverter() : base(FontWeights.Bold, FontWeights.Normal)
    {

    }
}
