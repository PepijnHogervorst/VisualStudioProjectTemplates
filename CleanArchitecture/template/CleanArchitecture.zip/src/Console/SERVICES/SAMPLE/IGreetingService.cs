﻿namespace $safeprojectname$.Services.Sample;

public interface IGreetingService
{
    void Run();
}