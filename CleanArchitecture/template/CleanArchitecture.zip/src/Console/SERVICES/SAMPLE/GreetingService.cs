﻿using Microsoft.Extensions.Logging;

namespace $safeprojectname$.Services.Sample;

public class GreetingService : IGreetingService
{
    private readonly ILogger<GreetingService> _log;

    public GreetingService(ILogger<GreetingService> log)
    {
        _log = log;
    }

    public void Run()
    {
        System.$safeprojectname$.WriteLine($"Hello there developer! Replace this class with your own console program!");
        System.$safeprojectname$.WriteLine($"Press a key to close down console..");
        System.$safeprojectname$.ReadKey();
    }
}
